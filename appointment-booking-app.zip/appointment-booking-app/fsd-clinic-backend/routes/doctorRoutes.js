import express from "express";
import User from "../models/User.js";
import Appointment from "../models/Appointment.js";
import {
  getDoctorQueue,
  updateAppointmentStatus,
} from "../controllers/doctorController.js";
import { protect, authorize } from "../middleware/authMiddleware.js";

const router = express.Router();

// ✅ Fetch all doctors
router.get("/", protect, async (req, res) => {
  try {
    const doctors = await User.find({ role: "doctor" }).select("-password");
    res.json(doctors);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

// Doctor’s queue — must come before /:id
router.get("/queue", protect, authorize("doctor"), getDoctorQueue);

// Get single doctor by id
router.get("/:id", protect, async (req, res) => {
  try {
    const doctor = await User.findById(req.params.id).select("-password");
    if (!doctor || doctor.role !== "doctor") {
      return res.status(404).json({ message: "Doctor not found" });
    }
    res.json(doctor);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

// Update appointment status
router.put(
  "/appointments/:id",
  protect,
  authorize("doctor"),
  updateAppointmentStatus
);

export default router;
