import Navbar from "../components/Navbar";

const Home = () => {
  return (
    <div>
      {/* Navbar displayed on all pages */}
     

      {/* Home content */}
      <div className="max-w-7xl mx-auto p-6 text-center">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">
          Welcome to Clinic System
        </h1>
        <p className="text-lg text-gray-600">
          Manage appointments, patients, and doctors efficiently.
        </p>
      </div>
    </div>
  );
};

export default Home;
