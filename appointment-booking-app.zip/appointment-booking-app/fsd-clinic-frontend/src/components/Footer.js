const Footer = () => {
  return (
    <footer className="bg-blue-600 text-white p-4 text-center mt-8">
      <p>Smart Clinic Management System</p>
      <p>Ira Homes,Chennai, Tamil Nadu</p>
      <p>📞 +91-6382087712 | ✉️ ch.en.u4aie22029@ch.students.amrita.edu</p>
    </footer>
  );
};

export default Footer;
