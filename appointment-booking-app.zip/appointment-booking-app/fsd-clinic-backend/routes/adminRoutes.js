import express from "express";
import {
  getAllUsers,
  deleteUser,
  updateUserByAdmin,
} from "../controllers/userController.js";
import {
  getAllAppointments,
  cancelAppointment,
} from "../controllers/appointmentController.js";
import { protect, authorize } from "../middleware/authMiddleware.js";

const router = express.Router();

// All routes protected + admin-only
router.use(protect);
router.use(authorize("admin"));

// User management
router.get("/users", getAllUsers);
router.put("/users/:id", updateUserByAdmin);
router.delete("/users/:id", deleteUser);

// Appointment management
router.get("/appointments", getAllAppointments);
router.delete("/appointments/:id", cancelAppointment);

export default router;
