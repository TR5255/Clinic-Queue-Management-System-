import express from "express";
import {
  getUserProfile,
  updateUserProfile,
  getAllUsers,
  deleteUser,
  updateUserByAdmin,
  getDoctorsWithSpecialization
} from "../controllers/userController.js";
import { protect, authorize } from "../middleware/authMiddleware.js";
import { upload } from "../middleware/uploadMiddleware.js";

const router = express.Router();

// --------------------
// Patient/Doctor routes
// --------------------
router.get("/profile", protect, getUserProfile);
router.put("/profile", protect, upload.single("profilePic"), updateUserProfile);
// Get doctors with specialization
router.get("/doctors", protect, authorize("patient"), getDoctorsWithSpecialization);

// --------------------
// Admin-only routes
// --------------------
// All admin routes are prefixed with /admin/users for consistency
router.get("/admin/users", protect, authorize("admin"), getAllUsers);
router.put("/admin/users/:id", protect, authorize("admin"), updateUserByAdmin);
router.delete("/admin/users/:id", protect, authorize("admin"), deleteUser);

export default router;
