import Appointment from "../models/Appointment.js";

// Get queue for logged-in doctor
export const getDoctorQueue = async (req, res) => {
  try {
    const doctorId = req.user._id;

    if (!doctorId) {
      return res.status(401).json({ message: "Doctor not found in request" });
    }

    // Fetch appointments assigned to this doctor that are not completed/cancelled
    const queue = await Appointment.find({
      doctor: doctorId,
      status: { $in: ["pending", "confirmed","scheduled"] },
    })
      .populate("patient", "name email")
      .sort({ date: 1 }); // earliest first

    res.json(queue);
  } catch (err) {
    console.error("Error fetching queue:", err);
    res.status(500).json({ message: "Server error" });
  }
};

// Update appointment status
export const updateAppointmentStatus = async (req, res) => {
  try {
    const appointment = await Appointment.findById(req.params.id);

    if (!appointment) {
      return res.status(404).json({ message: "Appointment not found" });
    }

    // Only the assigned doctor can update
    if (appointment.doctor.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized" });
    }

    const { status } = req.body;
    appointment.status = status;
    await appointment.save();

    res.json({ message: "Appointment status updated", appointmentId: appointment._id, status });
  } catch (err) {
    console.error("Error updating appointment:", err);
    res.status(500).json({ message: "Server error" });
  }
};
