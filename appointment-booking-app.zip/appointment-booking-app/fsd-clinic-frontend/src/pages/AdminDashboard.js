import { useEffect, useState, useContext, useCallback } from "react";
import axios from "../utils/api";
import { AuthContext } from "../context/AuthContext";

const AdminDashboard = () => {
  const { user } = useContext(AuthContext);
  const [users, setUsers] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(false);

  // Fetch users
  const fetchUsers = useCallback(async () => {
    try {
      const { data } = await axios.get("/admin/users", {
        headers: { Authorization: `Bearer ${user?.token}` },
      });
      setUsers(data || []);
    } catch (err) {
      console.error(err);
      setUsers([]);
    }
  }, [user?.token]);

  // Fetch appointments
  const fetchAppointments = useCallback(async () => {
    try {
      const { data } = await axios.get("/appointments", {
        headers: { Authorization: `Bearer ${user?.token}` },
      });
      setAppointments(data || []);
    } catch (err) {
      console.error(err);
      setAppointments([]);
    }
  }, [user?.token]);

  useEffect(() => {
    if (user?.token) {
      fetchUsers();
      fetchAppointments();
    }
  }, [user?.token, fetchUsers, fetchAppointments]);

  // Update user role
  const handleRoleChange = async (userId, newRole) => {
    try {
      setLoading(true);
await axios.put(`/admin/users/${userId}`, { role: newRole }, {
  headers: { Authorization: `Bearer ${user?.token}` },
});

      fetchUsers();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Delete user
  const handleDeleteUser = async (userId) => {
    if (!window.confirm("Are you sure you want to delete this user?")) return;
    try {
      setLoading(true);
await axios.delete(`/admin/users/${userId}`, {
  headers: { Authorization: `Bearer ${user?.token}` },
});

      fetchUsers();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      <h1 className="text-3xl md:text-4xl font-bold text-center mb-6 text-gray-800">
        Admin Dashboard
      </h1>

      {/* Users Table */}
      <div className="bg-white shadow-md rounded-lg p-4 md:p-6 overflow-x-auto">
        <h2 className="text-2xl font-semibold mb-4">Users</h2>
        <table className="w-full border-collapse border text-left">
          <thead>
            <tr className="bg-gray-200">
              <th className="border p-2">Name</th>
              <th className="border p-2">Email</th>
              <th className="border p-2">Role</th>
              <th className="border p-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.filter(Boolean).map((u) => (
              <tr key={u._id} className="hover:bg-gray-50">
                <td className="border p-2">{u?.name || "N/A"}</td>
                <td className="border p-2">{u?.email || "N/A"}</td>
                <td className="border p-2">
                  <select
                    value={u?.role || "patient"}
                    onChange={(e) => handleRoleChange(u._id, e.target.value)}
                    className="border rounded px-2 py-1"
                    disabled={loading || u?.role === "admin"}
                  >
                    <option value="patient">Patient</option>
                    <option value="doctor">Doctor</option>
                    <option value="admin">Admin</option>
                  </select>
                </td>
                <td className="border p-2">
                  {u?.role !== "admin" ? (
                    <button
                      className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded transition-colors"
                      onClick={() => handleDeleteUser(u._id)}
                      disabled={loading}
                    >
                      Delete
                    </button>
                  ) : (
                    <span className="text-gray-500">Protected</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Appointments Table */}
      <div className="bg-white shadow-md rounded-lg p-4 md:p-6 overflow-x-auto">
        <h2 className="text-2xl font-semibold mb-4">Appointments</h2>
        <table className="w-full border-collapse border text-left">
          <thead>
            <tr className="bg-gray-200">
              <th className="border p-2">Patient</th>
              <th className="border p-2">Doctor</th>
              <th className="border p-2">Date</th>
              <th className="border p-2">Status</th>
            </tr>
          </thead>
          <tbody>
            {appointments.filter(Boolean).map((appt) => (
              <tr key={appt._id} className="hover:bg-gray-50">
                <td className="border p-2">{appt?.patient?.name || "N/A"}</td>
                <td className="border p-2">{appt?.doctor?.name || "N/A"}</td>
                <td className="border p-2">
                  {appt?.date ? new Date(appt.date).toLocaleString() : "N/A"}
                </td>
                <td className="border p-2">{appt?.status || "N/A"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminDashboard;
