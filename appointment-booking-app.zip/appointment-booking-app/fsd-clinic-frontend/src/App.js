import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, AuthContext } from "./context/AuthContext";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Login from "./pages/Login";
import Register from "./pages/Register";
import PatientDashboard from "./pages/PatientDashboard";
import DoctorDashboard from "./pages/DoctorDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import BookAppointment from "./pages/BookAppointment";
import Profile from "./pages/Profile";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import Home from "./pages/Home"; // <-- import Home page
import PrivateRoute from "./components/PrivateRoute";
import { useContext } from "react";

const DefaultRoute = () => {
  const { user } = useContext(AuthContext);

  if (!user) return <Navigate to="/Home" />;

  switch (user.role) {
    case "patient":
      return <Navigate to="/patient/dashboard" />;
    case "doctor":
      return <Navigate to="/doctor/dashboard" />;
    case "admin":
      return <Navigate to="/admin/dashboard" />;
    default:
      return <Navigate to="/Home" />;
  }
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="flex flex-col min-h-screen">
          {/* Navbar always at the top */}
          <Navbar />

          {/* Main page content expands */}
          <main className="flex-grow">
            <Routes>
              {/* Home route */}
              <Route path="/home" element={<Home />} />

              {/* Default / smart redirect */}
              <Route path="/" element={<DefaultRoute />} />

              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/reset-password/:token" element={<ResetPassword />} />

              {/* Patient */}
              <Route
                path="/patient/dashboard"
                element={
                  <PrivateRoute role="patient">
                    <PatientDashboard />
                  </PrivateRoute>
                }
              />
              <Route
                path="/book/:doctorId"
                element={
                  <PrivateRoute role="patient">
                    <BookAppointment />
                  </PrivateRoute>
                }
              />

              {/* Doctor */}
              <Route
                path="/doctor/dashboard"
                element={
                  <PrivateRoute role="doctor">
                    <DoctorDashboard />
                  </PrivateRoute>
                }
              />

              {/* Admin */}
              <Route
                path="/admin/dashboard"
                element={
                  <PrivateRoute role="admin">
                    <AdminDashboard />
                  </PrivateRoute>
                }
              />

              {/* Common */}
              <Route
                path="/profile"
                element={
                  <PrivateRoute>
                    <Profile />
                  </PrivateRoute>
                }
              />
            </Routes>
          </main>

          {/* Footer always at the bottom */}
          <Footer />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
