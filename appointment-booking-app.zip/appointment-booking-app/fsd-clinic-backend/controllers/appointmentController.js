import Appointment from "../models/Appointment.js";
import User from "../models/User.js";

// @desc   Patient books an appointment with a doctor
// @route  POST /api/appointments
// @access Patient
import sendEmail from "../utils/sendEmail.js";

export const bookAppointment = async (req, res) => {
  try {
    const { doctorId, date } = req.body;

    const doctor = await User.findById(doctorId);
    if (!doctor || doctor.role !== "doctor") {
      return res.status(404).json({ message: "Doctor not found" });
    }

    const appointment = await Appointment.create({
      patient: req.user._id,
      doctor: doctorId,
      date,
    });

    // Send email reminder to patient
    await sendEmail({
      to: req.user.email,
      subject: `Appointment Confirmation: ${new Date(date).toLocaleString()}`,
      text: `Hi ${req.user.name},\n\nYour appointment with Dr. ${doctor.name} is scheduled for ${new Date(date).toLocaleString()}.\n\nThank you!`,
    });

    // Optionally, send email to doctor as well
    await sendEmail({
      to: doctor.email,
      subject: `New Appointment Scheduled: ${new Date(date).toLocaleString()}`,
      text: `Hi Dr. ${doctor.name},\n\nYou have a new appointment with ${req.user.name} on ${new Date(date).toLocaleString()}.\n\nThank you!`,
    });

    // Real-time notify doctor via socket.io
    const io = req.app.get("io");
    io.emit("newAppointment", {
      doctorId,
      appointment,
    });

    res.status(201).json(appointment);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message });
  }
};


// @desc   Patient gets their own appointments
// @route  GET /api/appointments/my
// @access Patient
export const getMyAppointments = async (req, res) => {
  try {
    const appointments = await Appointment.find({ patient: req.user._id })
      .populate("doctor", "name specialization")
      .sort({ date: 1 });

    res.json(appointments);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @desc   Patient cancels their appointment
// @route  DELETE /api/appointments/:id
// @access Patient
export const cancelAppointment = async (req, res) => {
  try {
    const appointment = await Appointment.findById(req.params.id);

    if (!appointment) return res.status(404).json({ message: "Appointment not found" });

    if (appointment.patient.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to cancel this appointment" });
    }

    appointment.status = "cancelled";
    await appointment.save();

    const io = req.app.get("io");
    io.emit("appointmentCancelled", { appointmentId: appointment._id });

    res.json({ message: "Appointment cancelled successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @desc   Admin gets all appointments
// @route  GET /api/appointments
// @access Admin
export const getAllAppointments = async (req, res) => {
  try {
    const appointments = await Appointment.find()
      .populate("patient", "name email")
      .populate("doctor", "name specialization")
      .sort({ date: 1 });

    res.json(appointments);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
