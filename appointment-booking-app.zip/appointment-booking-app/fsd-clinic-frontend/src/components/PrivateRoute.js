import { useContext } from "react";
import { Navigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

/**
 * @param {ReactNode} children - Component to render if authorized
 * @param {Array<string>} roles - Allowed roles for this route
 */
const PrivateRoute = ({ children, roles }) => {
  const { user } = useContext(AuthContext);

  if (!user) {
    // Not logged in → redirect to login
    return <Navigate to="/login" />;
  }

  if (roles && !roles.includes(user.role)) {
    // Logged in but role not allowed → redirect to home or login
    return <Navigate to="/login" />;
  }

  // Authorized → render the children
  return children;
};

export default PrivateRoute;
