import cron from "node-cron";
import sendEmail from "./sendEmail.js";
import Appointment from "../models/Appointment.js";
import User from "../models/User.js";

// Runs every 30 minutes and checks for upcoming appointments
export const startReminderScheduler = () => {
  cron.schedule("*/30 * * * *", async () => {
    try {
      const now = new Date();
      const oneHourLater = new Date(now.getTime() + 60 * 60 * 1000); // +1 hour

      // Find appointments happening within the next hour
      const upcomingAppointments = await Appointment.find({
        date: { $gte: now, $lte: oneHourLater },
      })
        .populate("patient", "name email")
        .populate("doctor", "name email");

      for (const appt of upcomingAppointments) {
        // Send email reminder to patient
        await sendEmail({
          to: appt.patient.email,
          subject: "⏰ Appointment Reminder",
          text: `Hi ${appt.patient.name},\n\nThis is a reminder for your appointment with Dr. ${appt.doctor.name} at ${new Date(
            appt.date
          ).toLocaleString()}.\n\nThank you!`,
        });

        // Send email reminder to doctor
        await sendEmail({
          to: appt.doctor.email,
          subject: "⏰ Appointment Reminder",
          text: `Hi Dr. ${appt.doctor.name},\n\nThis is a reminder for your appointment with ${appt.patient.name} at ${new Date(
            appt.date
          ).toLocaleString()}.\n\nThank you!`,
        });

        console.log("✅ Reminder sent for appointment:", appt._id);
      }
    } catch (err) {
      console.error("❌ Error sending reminders:", err.message);
    }
  });

  console.log("🔔 Reminder scheduler started (checks every 30 min).");
};
