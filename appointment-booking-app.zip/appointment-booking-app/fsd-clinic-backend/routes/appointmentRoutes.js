import express from "express";
import {
  bookAppointment,
  getMyAppointments,
  cancelAppointment,
  getAllAppointments,
} from "../controllers/appointmentController.js";
import { protect, authorize } from "../middleware/authMiddleware.js";

const router = express.Router();

// patient routes
router.post("/", protect, authorize("patient"), bookAppointment);
router.get("/my", protect, authorize("patient"), getMyAppointments);
router.delete("/:id", protect, authorize("patient"), cancelAppointment);

// admin route
router.get("/", protect, authorize("admin"), getAllAppointments);

export default router;
