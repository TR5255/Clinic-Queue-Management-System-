import { useContext, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import axios from "../utils/api";

const Profile = () => {
  const { user, setUser } = useContext(AuthContext);
  const [formData, setFormData] = useState({
    name: user?.name || "",
    email: user?.email || "",
    phone: user?.phone || "",
    address: user?.address || "",
    specialization: user?.specialization || "",
  });
  const [profilePic, setProfilePic] = useState(user?.profilePic || "");
  const [preview, setPreview] = useState(user?.profilePic || "");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  // Handle text input changes
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Handle image file selection
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfilePic(file);
      setPreview(URL.createObjectURL(file)); // Preview immediately
    }
  };

  // Handle form submission
const handleUpdate = async () => {
  try {
    setLoading(true);

    // Prepare FormData
    const updateData = new FormData();
    updateData.append("name", formData.name);
    updateData.append("email", formData.email);
    if (formData.phone) updateData.append("phone", formData.phone);
    if (formData.address) updateData.append("address", formData.address);
    if (profilePic) updateData.append("profilePic", profilePic); // use profilePic state

    const { data } = await axios.put(`/users/profile`, updateData, {
      headers: {
        Authorization: `Bearer ${user.token}`, // required for auth
        "Content-Type": "multipart/form-data",
      },
    });

    setUser(data); // update context
    setMessage("Profile updated successfully!");
  } catch (err) {
    console.error(err);
    setMessage(err.response?.data?.message || "Error updating profile.");
  } finally {
    setLoading(false);
  }
};


  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-3xl md:text-4xl font-bold mb-6 text-center text-gray-800">
        My Profile
      </h1>

      <div className="bg-white p-6 md:p-8 rounded-xl shadow-md space-y-6">
        {/* Profile Picture */}
        <div className="flex flex-col items-center space-y-4">
          <img
            src={preview || "/default-profile.png"}
            alt="Profile"
            className="w-32 h-32 rounded-full object-cover border-2 border-blue-500"
          />
          <input type="file" accept="image/*" onChange={handleFileChange} />
        </div>

        {/* Form Fields */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block font-semibold mb-1">Name</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              className="border p-2 rounded w-full focus:outline-blue-400"
            />
          </div>
          <div>
            <label className="block font-semibold mb-1">Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="border p-2 rounded w-full focus:outline-blue-400"
            />
          </div>
          <div>
            <label className="block font-semibold mb-1">Phone</label>
            <input
              type="text"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              className="border p-2 rounded w-full focus:outline-blue-400"
            />
          </div>
          <div>
            <label className="block font-semibold mb-1">Address</label>
            <input
              type="text"
              name="address"
              value={formData.address}
              onChange={handleChange}
              className="border p-2 rounded w-full focus:outline-blue-400"
            />
          </div>
          {user.role === "doctor" && (
            <div className="md:col-span-2">
              <label className="block font-semibold mb-1">Specialization</label>
              <input
                type="text"
                name="specialization"
                value={formData.specialization}
                onChange={handleChange}
                className="border p-2 rounded w-full focus:outline-blue-400"
              />
            </div>
          )}
          <div className="md:col-span-2">
            <label className="block font-semibold mb-1">Role</label>
            <input
              type="text"
              value={user.role}
              disabled
              className="border p-2 rounded w-full bg-gray-100 cursor-not-allowed"
            />
          </div>
        </div>

        {/* Message */}
        {message && (
          <p
            className={`text-center font-medium ${
              message.includes("success") ? "text-green-600" : "text-red-600"
            }`}
          >
            {message}
          </p>
        )}

        {/* Update Button */}
        <div className="text-center">
          <button
            onClick={handleUpdate}
            disabled={loading}
            className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded font-medium transition-colors"
          >
            {loading ? "Updating..." : "Update Profile"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Profile;
