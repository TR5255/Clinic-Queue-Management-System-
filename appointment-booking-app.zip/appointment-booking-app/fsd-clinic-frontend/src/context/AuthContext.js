import { createContext, useState } from "react";
import axios from "../utils/api"; // adjust if you use a custom axios instance

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  // Safely read user from localStorage
  const storedUser = localStorage.getItem("user");
  const [user, setUser] = useState(
    storedUser && storedUser !== "undefined" ? JSON.parse(storedUser) : null
  );

  // Login function
  const login = async (email, password) => {
    try {
      const { data } = await axios.post("/auth/login", { email, password });

      // Set user state and localStorage
      setUser(data);
      localStorage.setItem("user", JSON.stringify(data));

      return data; // you can use this in Login.js for redirection
    } catch (err) {
      console.error("Login failed:", err);
      throw err;
    }
  };

  // Logout function
  const logout = () => {
    setUser(null);
    localStorage.removeItem("user");
  };

  return (
    <AuthContext.Provider value={{ user, setUser, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
