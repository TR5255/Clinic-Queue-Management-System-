import { useEffect, useState, useContext, useCallback } from "react";
import { AuthContext } from "../context/AuthContext";
import { SocketContext } from "../context/SocketContext";
import axios from "../utils/api";
import { Link } from "react-router-dom";

const PatientDashboard = () => {
  const { user } = useContext(AuthContext);
  const { socket } = useContext(SocketContext);
  const [appointments, setAppointments] = useState([]);
  const [doctors, setDoctors] = useState([]);

  const fetchAppointments = useCallback(async () => {
    try {
      const { data } = await axios.get("/appointments/my", {
        headers: { Authorization: `Bearer ${user.token}` },
      });
      setAppointments(data);
    } catch (err) {
      console.error(err);
    }
  }, [user.token]);

  const fetchDoctors = useCallback(async () => {
    try {
      const { data } = await axios.get("/doctors", {
        headers: { Authorization: `Bearer ${user.token}` },
      });
      setDoctors(data);
    } catch (err) {
      console.error(err);
    }
  }, [user.token]);

  useEffect(() => {
    fetchAppointments();
    fetchDoctors();
  }, [fetchAppointments, fetchDoctors]);

  useEffect(() => {
    if (!socket) return;

    socket.on("appointmentUpdated", ({ appointmentId, status }) => {
      setAppointments((prev) =>
        prev.map((appt) =>
          appt._id === appointmentId ? { ...appt, status } : appt
        )
      );
      alert(`Your appointment status has changed to "${status}"`);
    });

    socket.on("appointmentCancelled", ({ appointmentId }) => {
      setAppointments((prev) =>
        prev.map((appt) =>
          appt._id === appointmentId ? { ...appt, status: "cancelled" } : appt
        )
      );
      alert(`Your appointment has been cancelled`);
    });

    return () => {
      socket.off("appointmentUpdated");
      socket.off("appointmentCancelled");
    };
  }, [socket]);

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <h1 className="text-3xl md:text-4xl font-bold mb-8 text-center md:text-left text-gray-800">
        Welcome, {user.name}
      </h1>

      {/* Doctors Section */}
      <section className="mb-10">
        <h2 className="text-2xl font-semibold mb-6 text-gray-700">Available Doctors</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {doctors.map((doctor) => (
            <div
              key={doctor._id}
              className="bg-white p-5 rounded-xl shadow-md hover:shadow-lg transition-shadow flex flex-col justify-between"
            >
              <div>
                <h3 className="text-lg font-bold text-gray-900">{doctor.name}</h3>
                <p className="text-gray-600 text-sm">{doctor.specialization || "General"} </p>
                <p className="text-gray-500 text-sm">{doctor.email}</p>
              </div>
              <Link
                to={`/book/${doctor._id}`}
                className="mt-4 bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded text-center font-medium transition-colors"
              >
                Book Appointment
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* Appointments Section */}
      <section>
        <h2 className="text-2xl font-semibold mb-6 text-gray-700">Your Appointments</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {appointments.length === 0 && (
            <div className="bg-white p-5 rounded-xl shadow-md text-gray-500">
              No upcoming appointments
            </div>
          )}
          {appointments.map((appt) => (
            <div
              key={appt._id}
              className="bg-white p-5 rounded-xl shadow-md flex flex-col justify-between hover:shadow-lg transition-shadow"
            >
              <p className="text-gray-800 font-semibold mb-2">
                With Dr. {appt?.doctor?.name}
              </p>
              <p className="text-gray-600 mb-2">
                {new Date(appt.date).toLocaleString()}
              </p>
              <span
                className={`inline-block text-sm font-medium px-3 py-1 rounded-full ${
                  appt.status === "completed"
                    ? "bg-green-100 text-green-800"
                    : appt.status === "cancelled"
                    ? "bg-red-100 text-red-800"
                    : "bg-yellow-100 text-yellow-800"
                }`}
              >
                {appt.status}
              </span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default PatientDashboard;
