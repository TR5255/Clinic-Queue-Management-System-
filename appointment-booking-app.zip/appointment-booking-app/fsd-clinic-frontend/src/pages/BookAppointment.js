import { useState, useEffect, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "../utils/api";
import { AuthContext } from "../context/AuthContext";

const BookAppointment = () => {
  const { doctorId } = useParams();
  const navigate = useNavigate();
  const { user } = useContext(AuthContext);
  const [date, setDate] = useState("");
  const [doctor, setDoctor] = useState(null);

  useEffect(() => {
const fetchDoctor = async () => {
  const { data } = await axios.get(`/doctors/${doctorId}`, {
    headers: { Authorization: `Bearer ${user.token}` },
  });
  setDoctor(data);
};

    fetchDoctor();
  }, [doctorId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("/appointments", { doctorId, date,patientId:user._id });
      alert("Appointment booked!");
      navigate("/patient/dashboard");
    } catch (err) {
      console.error(err);
      alert("Error booking appointment");
    }
  };

  if (!doctor) return <p>Loading...</p>;

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Book Appointment with {doctor.name}</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1 font-semibold">Date & Time</label>
          <input
            type="datetime-local"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="border p-2 rounded w-full"
            required
          />
        </div>
        <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">
          Book
        </button>
      </form>
    </div>
  );
};

export default BookAppointment;
