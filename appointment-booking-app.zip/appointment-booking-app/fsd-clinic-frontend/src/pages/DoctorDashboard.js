import { useEffect, useState, useContext } from "react";
import axios from "../utils/api";
import { AuthContext } from "../context/AuthContext";
import { io } from "socket.io-client";

const DoctorDashboard = () => {
  const { user } = useContext(AuthContext);
  const [queue, setQueue] = useState([]);

  const fetchQueue = async () => {
    try {
      const { data } = await axios.get("/doctors/queue", {
        headers: { Authorization: `Bearer ${user.token}` },
      });
      setQueue(data);
    } catch (err) {
      console.error("fetchQueue", err);
    }
  };

  useEffect(() => {
    fetchQueue();

    const socket = io("http://localhost:5000");
    socket.on("newAppointment", (data) => {
      if (data.doctorId === user._id) {
        setQueue((prev) => [...prev, data.appointment]);
      }
    });

    socket.on("appointmentUpdated", (data) => {
      setQueue((prev) =>
        prev.map((appt) =>
          appt._id === data.appointmentId ? { ...appt, status: data.status } : appt
        )
      );
    });

    return () => socket.disconnect();
  }, [user._id]);

  const updateStatus = async (id, status) => {
    try {
      await axios.put(`/doctors/appointments/${id}`, { status });
      setQueue((prev) =>
        prev.map((appt) => (appt._id === id ? { ...appt, status } : appt))
      );
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <h1 className="text-3xl md:text-4xl font-bold mb-8 text-center md:text-left text-gray-800">
        Doctor Dashboard
      </h1>

      {queue.length === 0 ? (
        <p className="text-gray-500 text-center">No patients in queue.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {queue.map((appt) => (
            <div
              key={appt._id}
              className="bg-white p-5 rounded-xl shadow-md hover:shadow-lg transition-shadow flex flex-col justify-between"
            >
              <div className="mb-4">
                <p className="text-lg font-bold text-gray-900">{appt.patient.name}</p>
                <p className="text-gray-600">{new Date(appt.date).toLocaleString()}</p>
                <span
                  className={`inline-block mt-2 text-sm font-medium px-3 py-1 rounded-full ${
                    appt.status === "completed"
                      ? "bg-green-100 text-green-800"
                      : appt.status === "cancelled"
                      ? "bg-red-100 text-red-800"
                      : "bg-yellow-100 text-yellow-800"
                  }`}
                >
                  {appt.status}
                </span>
              </div>
              <div className="flex justify-between mt-auto">
                <button
                  onClick={() => updateStatus(appt._id, "completed")}
                  className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded font-medium transition-colors flex-1 mr-2"
                >
                  Complete
                </button>
                <button
                  onClick={() => updateStatus(appt._id, "cancelled")}
                  className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded font-medium transition-colors flex-1 ml-2"
                >
                  Cancel
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default DoctorDashboard;
