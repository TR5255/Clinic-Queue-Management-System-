import User from "../models/User.js";

// @desc   Get logged-in user profile
// @route  GET /api/users/profile
// @access Private
export const getUserProfile = async (req, res) => {
  try {
    res.json(req.user); // added by authMiddleware
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @desc   Update user profile
// @route  PUT /api/users/profile
// @access Private
export const updateUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);

    if (!user) return res.status(404).json({ message: "User not found" });

    // Update basic info
    user.name = req.body.name || user.name;
    user.email = req.body.email || user.email;
    user.phone = req.body.phone || user.phone;
    user.address = req.body.address || user.address;
    user.specialization = req.body.specialization || user.specialization;

    // If profile picture uploaded via multer
    if (req.file) {
      user.profilePic = `/uploads/${req.file.filename}`;
    }

    // Update password if provided
    if (req.body.password) {
      user.password = req.body.password; // hashed in pre-save hook
    }

    const updatedUser = await user.save();
    res.json({
      _id: updatedUser._id,
      name: updatedUser.name,
      email: updatedUser.email,
      role: updatedUser.role,
      phone: updatedUser.phone,
      address: updatedUser.address,
      specialization: updatedUser.specialization,
      profilePic: updatedUser.profilePic,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
export const getAllDoctors = async (req, res) => {
  try {
    const doctors = await User.find({ role: "doctor" });
    res.json(doctors);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get all doctors with specialization

export const getDoctorsWithSpecialization = async (req, res) => {
  try {
    const doctors = await User.find({ role: "doctor" }).select(
      "name email specialization profilePic phone address"
    );

    res.status(200).json(doctors);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to fetch doctors" });
  }
};

// ================== Admin Controls ==================

// @desc   Get all users (Admin only)
// @route  GET /api/users
// @access Admin
export const getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select("-password");
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @desc   Delete user (Admin only)
// @route  DELETE /api/users/:id
// @access Admin
export const deleteUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) return res.status(404).json({ message: "User not found" });

    await user.deleteOne();
    res.json({ message: "User deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @desc   Update user role/info (Admin only)
// @route  PUT /api/users/:id
// @access Admin
export const updateUserByAdmin = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) return res.status(404).json({ message: "User not found" });

    user.name = req.body.name || user.name;
    user.email = req.body.email || user.email;
    user.role = req.body.role || user.role;
    user.specialization = req.body.specialization || user.specialization;

    const updatedUser = await user.save();
    res.json(updatedUser);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
